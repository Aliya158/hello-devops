def test_app():
   assert True
